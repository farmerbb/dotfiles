export default [
    [
        {
            name: "qwreey75",
            label: "Owner",
            link: "https://github.com/qwreey75",
            image: "qwreey75",
        },
        {
            name: "DaPigGuy",
            label: "Gnome 45 Port",
            link: "https://github.com/DaPigGuy",
            image: "DaPigGuy",
        },
        {
            name: "Leleat",
            label: "Style/Code improve",
            link: "https://github.com/Leleat",
            image: "Leleat",
        },
        {
            name: "kgdn",
            label: "Gnome 45 Port",
            link: "https://github.com/kgdn",
            image: "kgdn",
        },
    ],
    [
        {
            name: "DodoLeDev",
            label: "Readme/Code improve",
            link: "https://github.com/DodoLeDev",
            image: "DodoLeDev",
        },
        {
            name: "andia89",
            label: "Code improve",
            link: "https://github.com/andia89",
            image: "andia89",
        },
        {
            name: "DanGLES3",
            label: "Portuguese translation",
            link: "https://github.com/DanGLES3",
            image: "DanGLES3",
        },
        {
            name: "jcatfor",
            label: "Catalan translation",
            link: "https://github.com/jcatfor",
            image: "jcatfor",
        },
    ],
    [
        {
            name: "ondra05",
            label: "Czech translation",
            link: "https://github.com/ondra05",
            image: "ondra05",
        },
        {
            name: "daudix-UFO",
            label: "Russian translation",
            link: "https://github.com/daudix-UFO",
            image: "daudix-UFO",
        },
        {
            name: "JohnOberhauser",
            label: "Audio Input/Output",
            link: "https://github.com/JohnOberhauser",
            image: "JohnOberhauser",
        },
        {
            name: "314eter",
            label: "Bug fix/Code improve",
            link: "https://github.com/314eter",
            image: "314eter",
        },
    ]
]