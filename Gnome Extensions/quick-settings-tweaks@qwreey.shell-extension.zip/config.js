export default {
    isDevelopmentBuild: false,
    isReleaseBuild: false,
    isGithubBuild: false,
    version: "2.1",
    buildNumber: 8,
    baseGTypeName: "quick-settings-tweaks_",
    loggerPrefix: "[quick-settings-tweaks]",
};
